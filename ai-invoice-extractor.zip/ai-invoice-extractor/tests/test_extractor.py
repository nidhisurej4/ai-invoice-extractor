from pathlib import Path

from invoice_ai.extractor import extract_with_rules

SAMPLES = Path(__file__).parent.parent / "samples"


def load(name):
    return extract_with_rules((SAMPLES / name).read_text(encoding="utf-8"))


def test_extracts_header_fields():
    inv = load("01_freight_invoice.txt")
    assert inv.vendor == "Oceanic Freight Services"
    assert inv.invoice_number == "INV-2026-0142"
    assert inv.invoice_date == "2026-09-05"
    assert inv.due_date == "2026-10-05"
    assert inv.currency == "USD"
    assert (inv.subtotal, inv.tax, inv.total) == (3975.0, 397.5, 4372.5)


def test_extracts_line_items_and_skips_header_row():
    inv = load("01_freight_invoice.txt")
    assert len(inv.line_items) == 3
    assert inv.line_items[0].description == "Ocean freight 40HC INBLR-NLRTM"
    assert inv.line_items[0].amount == 3600.0


def test_currency_symbol_and_text_dates():
    inv = load("02_office_supplies.txt")
    assert inv.currency == "INR"
    assert inv.invoice_date == "2026-09-12"
    assert inv.tax == 918.0
