from pathlib import Path

from invoice_ai.extractor import extract_with_rules
from invoice_ai.models import Invoice, LineItem
from invoice_ai.validator import validate

SAMPLES = Path(__file__).parent.parent / "samples"


def test_clean_invoices_are_approved():
    for name in ("01_freight_invoice.txt", "02_office_supplies.txt"):
        inv = extract_with_rules((SAMPLES / name).read_text(encoding="utf-8"))
        result = validate(inv)
        assert result.status == "approved", (name, result.issues)


def test_bad_invoice_is_flagged_with_reasons():
    inv = extract_with_rules((SAMPLES / "03_mismatched_total.txt").read_text(encoding="utf-8"))
    result = validate(inv)
    assert result.status == "needs_review"
    assert any("total says 580.0" in i for i in result.issues)
    assert any("due date" in i for i in result.issues)


def test_missing_fields_are_reported():
    result = validate(Invoice(total=10.0, line_items=[LineItem("x", 1, 10)]))
    assert "missing vendor" in result.issues
    assert "missing currency" in result.issues
