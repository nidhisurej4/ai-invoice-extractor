from __future__ import annotations

from invoice_ai.extractor import extract
from invoice_ai.store import Store
from invoice_ai.validator import validate


def process(text: str, source: str, store: Store) -> dict:
    invoice = extract(text)
    result = validate(invoice)
    doc_id = store.save(source, invoice, result)
    return {"id": doc_id, "status": result.status, "issues": result.issues,
            "invoice": invoice.to_dict()}
