"""SQLite storage. Swap the connection for PostgreSQL in production."""
from __future__ import annotations

import json
import sqlite3
from pathlib import Path

from invoice_ai.models import Invoice
from invoice_ai.validator import ValidationResult

SCHEMA = """
CREATE TABLE IF NOT EXISTS documents (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    source        TEXT NOT NULL,
    vendor        TEXT,
    invoice_number TEXT,
    invoice_date  TEXT,
    due_date      TEXT,
    currency      TEXT,
    total         REAL,
    status        TEXT NOT NULL,
    issues        TEXT NOT NULL,
    payload       TEXT NOT NULL,
    created_at    TEXT DEFAULT CURRENT_TIMESTAMP
);
"""


class Store:
    def __init__(self, path: str | Path = "invoices.db"):
        self.conn = sqlite3.connect(path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self.conn.executescript(SCHEMA)

    def save(self, source: str, inv: Invoice, result: ValidationResult) -> int:
        cur = self.conn.execute(
            """INSERT INTO documents (source, vendor, invoice_number, invoice_date, due_date,
                                      currency, total, status, issues, payload)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (source, inv.vendor, inv.invoice_number, inv.invoice_date, inv.due_date,
             inv.currency, inv.total, result.status, json.dumps(result.issues),
             json.dumps(inv.to_dict())),
        )
        self.conn.commit()
        return cur.lastrowid

    def all(self, status: str | None = None) -> list[dict]:
        sql, args = "SELECT * FROM documents", ()
        if status:
            sql, args = sql + " WHERE status = ?", (status,)
        rows = self.conn.execute(sql + " ORDER BY id", args).fetchall()
        return [{**dict(r), "issues": json.loads(r["issues"])} for r in rows]
