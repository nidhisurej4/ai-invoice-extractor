"""Turn invoice emails into validated, structured data."""
