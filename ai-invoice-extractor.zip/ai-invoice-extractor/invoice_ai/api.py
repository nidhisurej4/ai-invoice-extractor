"""REST API: uvicorn invoice_ai.api:app --reload"""
from __future__ import annotations

import tempfile

from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.responses import FileResponse
from pydantic import BaseModel

from invoice_ai.exporter import export_xlsx
from invoice_ai.pipeline import process
from invoice_ai.store import Store

app = FastAPI(title="AI Invoice Extractor", version="0.1.0")
store = Store()


class TextIn(BaseModel):
    text: str
    source: str = "api"


@app.post("/documents")
def create_from_text(body: TextIn):
    return process(body.text, body.source, store)


@app.post("/documents/upload")
async def create_from_file(file: UploadFile = File(...)):
    if not file.filename.endswith((".txt", ".eml")):
        raise HTTPException(415, "Upload a .txt or .eml file")
    text = (await file.read()).decode("utf-8", errors="replace")
    return process(text, file.filename, store)


@app.get("/documents")
def list_documents(status: str | None = None):
    return store.all(status)


@app.get("/export.xlsx")
def export():
    path = tempfile.mktemp(suffix=".xlsx")
    export_xlsx(store.all(), path)
    return FileResponse(path, filename="invoices.xlsx")
