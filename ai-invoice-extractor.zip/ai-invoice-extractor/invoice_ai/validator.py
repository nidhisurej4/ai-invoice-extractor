"""Business checks. LLMs can misread numbers, so nothing is trusted until it
reconciles. Anything that fails is routed to a human instead of being exported
as if it were correct."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date

from invoice_ai.models import Invoice

TOLERANCE = 0.01
REQUIRED = ("vendor", "invoice_number", "invoice_date", "total", "currency")


@dataclass
class ValidationResult:
    status: str            # "approved" or "needs_review"
    issues: list[str]


def validate(inv: Invoice) -> ValidationResult:
    issues = [f"missing {f}" for f in REQUIRED if getattr(inv, f) in (None, "")]

    if inv.line_items and inv.subtotal is not None:
        items_sum = round(sum(i.amount for i in inv.line_items), 2)
        if abs(items_sum - inv.subtotal) > TOLERANCE:
            issues.append(f"line items sum to {items_sum}, subtotal says {inv.subtotal}")

    if None not in (inv.subtotal, inv.tax, inv.total):
        expected = round(inv.subtotal + inv.tax, 2)
        if abs(expected - inv.total) > TOLERANCE:
            issues.append(f"subtotal + tax = {expected}, total says {inv.total}")

    if inv.total is not None and inv.total <= 0:
        issues.append("total must be positive")

    if inv.invoice_date and inv.due_date:
        if date.fromisoformat(inv.due_date) < date.fromisoformat(inv.invoice_date):
            issues.append("due date is before invoice date")

    return ValidationResult("needs_review" if issues else "approved", issues)
