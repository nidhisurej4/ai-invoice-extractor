"""Excel export for the finance team: one sheet per status."""
from __future__ import annotations

from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill

COLUMNS = ["id", "source", "vendor", "invoice_number", "invoice_date", "due_date",
           "currency", "total", "issues"]


def export_xlsx(rows: list[dict], path: str) -> str:
    wb = Workbook()
    wb.remove(wb.active)
    for status, fill in (("approved", "C6EFCE"), ("needs_review", "FFEB9C")):
        ws = wb.create_sheet(status.replace("_", " ").title())
        ws.append([c.replace("_", " ").title() for c in COLUMNS])
        for cell in ws[1]:
            cell.font = Font(bold=True)
            cell.fill = PatternFill("solid", fgColor=fill)
        for r in (r for r in rows if r["status"] == status):
            ws.append([("; ".join(r[c]) if c == "issues" else r[c]) for c in COLUMNS])
        for col in ws.columns:
            ws.column_dimensions[col[0].column_letter].width = max(12, max(len(str(c.value or "")) for c in col) + 2)
        ws.freeze_panes = "A2"
    wb.save(path)
    return path
