"""Extraction: an LLM when an API key is set, a rule-based parser otherwise.

The rule-based path means the project runs (and CI passes) with no API key,
and gives a baseline to compare LLM accuracy against.
"""
from __future__ import annotations

import json
import os
import re
from datetime import datetime

from invoice_ai.models import Invoice, LineItem

PROMPT = """Extract the invoice from the email below. Reply with JSON only, no prose.
Schema:
{{"vendor": str|null, "invoice_number": str|null, "invoice_date": "YYYY-MM-DD"|null,
  "due_date": "YYYY-MM-DD"|null, "currency": "3-letter ISO code"|null,
  "subtotal": number|null, "tax": number|null, "total": number|null,
  "line_items": [{{"description": str, "quantity": number, "unit_price": number}}]}}
Use null for anything not stated. Do not guess or calculate missing values.

EMAIL:
{text}
"""


# ---------- LLM path ----------

def extract_with_llm(text: str) -> Invoice:
    import anthropic  # imported lazily so the offline path has no dependency

    client = anthropic.Anthropic()
    msg = client.messages.create(
        model=os.getenv("LLM_MODEL", "claude-haiku-4-5-20251001"),
        max_tokens=1500,
        messages=[{"role": "user", "content": PROMPT.format(text=text)}],
    )
    raw = msg.content[0].text.strip()
    raw = re.sub(r"^```(?:json)?\s*|\s*```$", "", raw)  # tolerate fenced output
    return Invoice.from_dict(json.loads(raw), extracted_by="llm")


# ---------- Rule-based path ----------

_DATE_FORMATS = ("%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y", "%d %b %Y", "%d %B %Y", "%b %d, %Y", "%B %d, %Y")
_CURRENCY_SYMBOLS = {"$": "USD", "€": "EUR", "£": "GBP", "₹": "INR"}
_MONEY = r"([A-Z]{3}|[$€£₹])?\s?([\d,]+\.?\d*)"


def _to_iso(value: str) -> str | None:
    value = value.strip().rstrip(".")
    for fmt in _DATE_FORMATS:
        try:
            return datetime.strptime(value, fmt).date().isoformat()
        except ValueError:
            continue
    return None


def _money(label: str, text: str) -> tuple[float | None, str | None]:
    m = re.search(rf"^\s*{label}\s*[:\-]?\s*{_MONEY}\s*$", text, re.I | re.M)
    if not m:
        return None, None
    cur = m.group(1)
    return float(m.group(2).replace(",", "")), _CURRENCY_SYMBOLS.get(cur, cur)


def _field(label: str, text: str) -> str | None:
    m = re.search(rf"{label}\s*[:#]?\s*(.+)", text, re.I)
    return m.group(1).strip() if m else None


def extract_with_rules(text: str) -> Invoice:
    inv = Invoice(extracted_by="rules")

    inv.vendor = _field(r"^From", text)
    if inv.vendor:
        inv.vendor = re.sub(r"\s*<.*?>", "", inv.vendor).strip()
    number = re.search(r"Invoice\s*(?:No\.?|Number|#)\s*[:#]?\s*([A-Z0-9\-/]+)", text, re.I)
    inv.invoice_number = number.group(1) if number else None

    if d := _field(r"Invoice Date", text):
        inv.invoice_date = _to_iso(d)
    if d := _field(r"Due Date", text):
        inv.due_date = _to_iso(d)

    inv.subtotal, c1 = _money("Subtotal", text)
    inv.tax, c2 = _money(r"(?:Tax|GST|VAT)(?:\s*\(.*?\))?", text)
    inv.total, c3 = _money(r"(?:Total|Amount Due)", text)
    inv.currency = c3 or c1 or c2

    # Line items like: "Ocean freight 40HC  | 2 | 1,800.00"
    for m in re.finditer(r"^\s*[-*]?\s*(.+?)\s*\|\s*([\d.]+)\s*\|\s*[A-Z$€£₹]*\s?([\d,]+\.?\d*)\s*$",
                         text, re.M):
        desc = m.group(1).strip()
        if desc.lower() in {"description", "item"}:
            continue
        inv.line_items.append(LineItem(desc, float(m.group(2)), float(m.group(3).replace(",", ""))))
    return inv


def extract(text: str) -> Invoice:
    if os.getenv("ANTHROPIC_API_KEY"):
        try:
            return extract_with_llm(text)
        except Exception as e:  # fall back rather than lose the document
            print(f"LLM extraction failed ({e}); using rule-based parser")
    return extract_with_rules(text)
