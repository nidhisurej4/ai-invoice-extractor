from __future__ import annotations

from dataclasses import asdict, dataclass, field


@dataclass
class LineItem:
    description: str
    quantity: float
    unit_price: float

    @property
    def amount(self) -> float:
        return round(self.quantity * self.unit_price, 2)


@dataclass
class Invoice:
    vendor: str | None = None
    invoice_number: str | None = None
    invoice_date: str | None = None   # ISO yyyy-mm-dd
    due_date: str | None = None
    currency: str | None = None
    subtotal: float | None = None
    tax: float | None = None
    total: float | None = None
    line_items: list[LineItem] = field(default_factory=list)
    extracted_by: str = "unknown"     # "llm" or "rules"

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict, extracted_by: str) -> "Invoice":
        items = [LineItem(i["description"], float(i["quantity"]), float(i["unit_price"]))
                 for i in d.get("line_items") or []]
        num = lambda k: float(d[k]) if d.get(k) is not None else None  # noqa: E731
        return cls(
            vendor=d.get("vendor"), invoice_number=d.get("invoice_number"),
            invoice_date=d.get("invoice_date"), due_date=d.get("due_date"),
            currency=d.get("currency"), subtotal=num("subtotal"), tax=num("tax"),
            total=num("total"), line_items=items, extracted_by=extracted_by,
        )
