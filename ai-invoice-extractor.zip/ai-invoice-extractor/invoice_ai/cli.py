"""Batch mode: python -m invoice_ai.cli samples/ --out invoices.xlsx"""
from __future__ import annotations

import argparse
from pathlib import Path

from invoice_ai.exporter import export_xlsx
from invoice_ai.pipeline import process
from invoice_ai.store import Store


def main() -> None:
    p = argparse.ArgumentParser(description="Extract invoices from a folder of .txt/.eml files")
    p.add_argument("folder")
    p.add_argument("--out", default="invoices.xlsx")
    p.add_argument("--db", default="invoices.db")
    args = p.parse_args()

    store = Store(args.db)
    files = sorted(f for f in Path(args.folder).iterdir() if f.suffix in {".txt", ".eml"})
    for f in files:
        r = process(f.read_text(encoding="utf-8"), f.name, store)
        flag = "OK   " if r["status"] == "approved" else "CHECK"
        print(f"[{flag}] {f.name}: {r['invoice']['vendor']} {r['invoice']['total']} "
              f"{'; '.join(r['issues'])}")
    export_xlsx(store.all(), args.out)
    print(f"\nProcessed {len(files)} files -> {args.out}")


if __name__ == "__main__":
    main()
